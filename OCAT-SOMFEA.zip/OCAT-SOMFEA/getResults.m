
clc;
clear;

load('ICPresult.mat');
allResults = zeros(9,2);

for i = 1:9
    for j = 1:5
        temp1(j) = data_MFEA(i).EvBestFitness(2*j-1,end);
        temp2(j) = data_MFEA(i).EvBestFitness(2*j,end);
    end
    allResults(i,1) = mean(temp1);
    allResults(i,2) = mean(temp2);
end

