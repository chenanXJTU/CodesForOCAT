function [rMatrix, tMatrix] = OCAT(pop1,pop1Value,pop2,pop2Value)
%ICP ��pop1��תƽ�ƶ�����pop2
%   �˴���ʾ��ϸ˵��
extractRate = 0.15;
[~,sortIndex] = sort(pop1Value,'ascend');
pop1 = pop1(sortIndex,:);
[~,sortIndex] = sort(pop2Value,'ascend');
pop2 = pop2(sortIndex,:);
if size(pop1,1)~= size(pop2,1)
    if size(pop1,1) < size(pop2,1)
        temp = size(pop2,1) - size(pop1,1);
        pop2((end-temp+1:end),:) = [];
    else
        temp = size(pop1,1) - size(pop2,1);
        pop1((end-temp+1:end),:) = [];
    end
end
extractNum = ceil(extractRate*size(pop1,1));
pop1 = pop1(1:extractNum,:);
pop2 = pop2(1:extractNum,:);

[num,dim] = size(pop1);
currIter = 0; 
maxIter = 50;

rMatrix = eye(dim, dim);    %��ʼ����ת������ƽ�ƾ���
tMatrix = zeros(dim,1);
tpop1 = (rMatrix*pop1' + tMatrix)';

distance = sum(sqrt(sum((tpop1 - pop2).^2,2)),1);
while currIter < maxIter
    pop22 = pop2;
    for i = 1: num                       %��pop1�е�ÿ�����壬�ҵ�pop2�о���������ĸ���
        temp = repmat(tpop1(i,:), size(pop22, 1), 1);
        diff = sqrt(sum((temp - pop22).^2,2));
        [~,corr(i)] = min(diff);
        pop22(corr(i),:) = inf;
    end
    tpop2 = pop2(corr,:);
    [R, T] = reg(tpop1, tpop2);
    rMatrix = R*rMatrix ;
    tMatrix = R * tMatrix + T;
    tpop1 = (rMatrix*pop1' + tMatrix)'; 
    temp = sum(sqrt(sum((tpop1 - tpop2).^2,2)),1);
    if abs(distance(end) - temp) < 1e-6
        break;
    end
    distance = [distance,temp];
    currIter = currIter + 1;
end

end

