Run MAIN.m to generate baseline results using the experimental setting provided in the technical report.

For suggestions please contact: Bingshui Da (Email: da0002ui@e.ntu.edu.sg).