function [rMatrix, tMatrix] = reg(pop1, pop2)
centerP1 = mean(pop1);
P1C = pop1 - centerP1;
P1C = P1C';
centerP2 = mean(pop2);
P2C = pop2 - centerP2;
P2C = P2C';

dim = size(P1C,1);
H = zeros(dim, dim);
for i = 1: size(P1C,2)
    temp = P1C(:,i)*P2C(:,i)';
    H = H + temp;
end
[U,~,V] = svd(H);
rMatrix = V*U';
if det(rMatrix) < 0
    sprintf("Reflection detected\n");
    V(:,2) = -1*V(:,2);
    rMatrix = V*U';
end
tMatrix = -rMatrix*centerP1' + centerP2';
end