clc;
clear ;

F1 = @(x, y)(x.^2 + y.^2);
F2 = @(x, y)((x - 10).^2 + (y - 10).^2);

P1 = -5 + rand(6, 2) * 10;
for i = 1: length(P1(:,1))
    P1Value(i) = F1(P1(i,1), P1(i,2));
end
figure(1);
plot(P1(:,1), P1(:,2) ,'*'); hold on;

P2 = 9 + rand(6, 2) * 2; 
for i = 1: length(P2(:,1))
    P2Value(i) = F1(P2(i,1), P2(i,2));
end
plot(P2(:,1), P2(:,2) ,'o'); 


figure(2);
plot(P1(:,1), P1(:,2) ,'*'); hold on;
plot(P2(:,1), P2(:,2) ,'o'); hold on;
[rMatrix,tMatrix] = ICP(P2,P2Value,P1,P1Value);
tPop = (rMatrix*P2'+tMatrix)';
plot(tPop(:,1), tPop(:,2) ,'+'); hold on;








