
clc;
clear;
maxFEs = 5000000;
popSize = 50;
selectionRate = 0.35;
reserveNum = 1;    % 
newIndividualNum = popSize - reserveNum;    %
selectionNum = max([2, reserveNum, ...
                     round(selectionRate * popSize)]);  %
AMS_num = round(0.5 * selectionNum);        %
AMS_delta = 2;
decrease_factor = 0.9;
increase_factor = 1.0 / decrease_factor;
sdr_threshold = 1.0;
selectionNum = ceil(selectionRate*popSize);
rand('state',sum(100 * clock));     %

for setID = 4
    disp(setID);
    testTimes = 15;
    Tasks = benchmark(setID);
    taskNum = length(Tasks);
    D = zeros(1, taskNum);
    for i = 1: taskNum
        D(i) = Tasks(i).dim;
    end
    Dim = max(D);
    max_NoImprovement_stretch = 25 + Dim;
    allOptTrace = cell(taskNum,testTimes);    
    for testCounter = 1:testTimes
        disp(testCounter);
        fesUsed = 0;
        optTrace = cell(taskNum,1);
        for i = 1: taskNum
            pop(i).chroms = rand(popSize, Dim);
            [pop(i).fitness, FEs] = evlFitness(pop(i).chroms, Tasks, i);
            fesUsed = fesUsed + FEs;
            [~,sortIndex] = sort(pop(i).fitness,'ascend');
            pop(i).chroms = pop(i).chroms(sortIndex,:);
            pop(i).fitness = pop(i).fitness(sortIndex,:);
            optTrace{i} = [optTrace{i}, pop(i).fitness(1)];

            pre_mu(i,:) = mean(pop(i).chroms(1:selectionNum,:), 1);
            improvedValue(i,:) = pop(i).fitness(1);
            no_improvement_stretch(i,:) = 0;
            sigma_multiplier(i,:) = 1.0;
        end
        t = 0;
        while fesUsed < maxFEs
            t = t + 1;
            if t > taskNum
                t = 1;
                pop = newPop;
            end
            improveIndex = find(pop(t).fitness < improvedValue(t));
            if(isempty(improveIndex))      %
                if (sigma_multiplier(t) <= 1.0)
                    no_improvement_stretch(t) = no_improvement_stretch(t) + 1;
                end
                if ((sigma_multiplier(t) > 1.0) || (no_improvement_stretch(t) >= max_NoImprovement_stretch))
                    sigma_multiplier(t) = decrease_factor * sigma_multiplier(t);
                end 
                if((sigma_multiplier(t) < 1.0) && (no_improvement_stretch(t) < max_NoImprovement_stretch))
                    sigma_multiplier(t) = 1.0;
                end
            else
                no_improvement_stretch(t) = 0;
                sigma_multiplier(t) = max(sigma_multiplier(t), 1.0);
                temp = pop(t).chroms;
                sdr = min(abs((mean(temp(improveIndex,:), 1) - mu)*sigma));
                if (sdr > sdr_threshold)
                    sigma_multiplier(t) = increase_factor * sigma_multiplier(t);
                end
            end

            samplePool = zeros(selectionNum*taskNum,Dim);
            targetPop = pop(t).chroms;
            targetPopVal = pop(t).fitness;
            count = 1;
            samplePool((count-1)*selectionNum + 1: count*selectionNum,:) = targetPop(1:selectionNum,:); 
            for i = 1:taskNum
                if i == t
                    continue;
                end
                sourcePop = pop(i).chroms;
                sourcePopVal = pop(i).fitness;
                [rMatrix,tMatrix] = OCAT(sourcePop, sourcePopVal,targetPop, targetPopVal);
                samples = (rMatrix*sourcePop(1:selectionNum,:)'+tMatrix)';
                count = count + 1;
                samplePool((count-1)*selectionNum + 1: count*selectionNum,:) = samples;
            end
            mu(t,:) = mean(targetPop(1:selectionNum,:), 1);
            improvedValue(t) = targetPopVal(1);    %

            gMu = mean(samplePool,1);
            cov_syn = cov(samplePool);
            cov_syn = cov_syn * sigma_multiplier(t);
            cov_syn = triu(cov_syn) + transpose(triu(cov_syn,1));  %
            [V_syn,D_syn] = eig(cov_syn);
            if (D_syn(1,1) <= 0)
                D_syn = D_syn+1.1*eye(Dim)*abs(D_syn(1,1));
                cov_syn = V_syn*D_syn*V_syn';
            end
            cov_syn = triu(cov_syn) + transpose(triu(cov_syn,1));  %
            sigma=inv(V_syn*(D_syn^0.5));

            tempPop=mvnrnd(gMu,cov_syn, newIndividualNum);
            tempPop(1:AMS_num,:) = tempPop(1:AMS_num,:) + AMS_delta * sigma_multiplier(t) * repmat(mu(t,:) - pre_mu(t,:), AMS_num, 1);    
            UBMatrix = repmat(ones(1,Dim), newIndividualNum, 1);   %
            LBMatrix = repmat(zeros(1,Dim), newIndividualNum, 1);
            tempIndex = tempPop > UBMatrix;            %
            tempPop(tempIndex) = 2 * UBMatrix(tempIndex) - tempPop(tempIndex);
            tempIndex = tempPop < LBMatrix;
            tempPop(tempIndex) = 2 * LBMatrix(tempIndex) - tempPop(tempIndex);

            [newFitness, FEs] = evlFitness(tempPop, Tasks, t);
            fesUsed = fesUsed + FEs;
            newPop(t).chroms = [pop(t).chroms(1:reserveNum, :); tempPop];
            newPop(t).fitness= [pop(t).fitness(1:reserveNum, :); newFitness];

            [~,sortIndex] = sort(newPop(t).fitness,'ascend');
            newPop(t).chroms = newPop(t).chroms(sortIndex,:);
            newPop(t).fitness = newPop(t).fitness(sortIndex,:);
            optTrace{t} = [optTrace{t}, newPop(t).fitness(1)];
            pre_mu(t,:) = mu(t,:);   %pre_muΪt-1���ľ�ֵ��muΪt���ľ�ֵ
        end
        fileName = sprintf('./results/S%02d/R%02d.mat', setID, testCounter);
        save(fileName, 'optTrace', '-v7');
    end
end

