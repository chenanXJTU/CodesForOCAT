function [fitness, FEs] = evlFitness(chromosomes, Tasks, i)
%EVLFITNESS �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
popSize = size(chromosomes, 1);
d = Tasks(i).dim;
chromosomes = chromosomes(:,1:d);
tempSolutions = repmat(Tasks(i).Lb, popSize, 1) + chromosomes.*repmat(Tasks(i).Ub - Tasks(i).Lb, popSize, 1);
fitness = zeros(popSize, 1);
for j = 1: popSize
    fitness(j) = Tasks(i).fnc(tempSolutions(j,:));
end
FEs = popSize;

end

